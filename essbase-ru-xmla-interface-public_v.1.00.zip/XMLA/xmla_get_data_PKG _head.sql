create or replace
package xmla_get_data_PKG is

/**
 CREATE TABLE  "XX_SRV_LOG_XMLA" 
   (	
    "SYSDATECREATION" TIMESTAMP (6) DEFAULT sysdate, 
	"XMLABODY" VARCHAR2(3900 BYTE), 
	"HTTPREQUEST" CLOB, 
	"SQLERRORCODE" VARCHAR2(80 BYTE), 
	"SQLERRORMESSAGE" VARCHAR2(3200 BYTE)
   );
**/
   TYPE essbaseCrossJoin_r IS RECORD
  ( dim01  VARCHAR2(160) ,
    dim02  VARCHAR2(160) ,
    dim03  VARCHAR2(160) ,
    dim04  VARCHAR2(160) ,
    dim05  VARCHAR2(160) ,
    dim06  VARCHAR2(160) ,
    dim07  VARCHAR2(160) ,
    dim08  VARCHAR2(160) ,
    dim09  VARCHAR2(160) ,
    dim10  VARCHAR2(160) ,
    dim11  VARCHAR2(160) ,
    dim12  VARCHAR2(160) ,
    dim13  VARCHAR2(160) ,
    dim14  VARCHAR2(160) ,
    dim15  VARCHAR2(160) ,
    dim16  VARCHAR2(160) ,
    dim17  VARCHAR2(160) ,
    dim18  VARCHAR2(160) ,
    dim19  VARCHAR2(160) ,
    dim20  VARCHAR2(160) ,
    dim21  VARCHAR2(160) ,
    DblValue number 
    );
  TYPE essbaseCrossJoin_T IS TABLE OF essbaseCrossJoin_r; 

 
   TYPE levelHierarshi_r IS RECORD
  ( lev01  VARCHAR2(160) ,
    lev02  VARCHAR2(160) ,
    lev03  VARCHAR2(160) ,
    lev04  VARCHAR2(160) ,
    lev05  VARCHAR2(160) ,
    lev06  VARCHAR2(160) ,
    lev07  VARCHAR2(160) ,
    lev08  VARCHAR2(160) ,
    lev09  VARCHAR2(160) ,
    lev10  VARCHAR2(160) ,
    lev11  VARCHAR2(160) ,
    lev12  VARCHAR2(160) ,
    lev13  VARCHAR2(160) ,
    lev14  VARCHAR2(160) ,
    lev15  VARCHAR2(160) ,
    lev16  VARCHAR2(160) ,
    lev17  VARCHAR2(160) ,
    lev18  VARCHAR2(160) ,
    lev19  VARCHAR2(160) ,
    lev20  VARCHAR2(160) ,
    lev21  VARCHAR2(160) 
    );
  TYPE levelHierarshi_T IS TABLE OF levelHierarshi_r; 
   
     TYPE cubeName_r IS RECORD
  ( AppName  VARCHAR2(160),
    CubeName  VARCHAR2(160)   
    );
  TYPE cubeName_T IS TABLE OF cubeName_r; 

   TYPE AppName_r IS RECORD
  ( AppName  VARCHAR2(160)  
    );
  TYPE AppName_T IS TABLE OF AppName_r; 
 
 TYPE DimensionList_r IS RECORD
( 
  CATALOG_NAME  VARCHAR2(160) ,
  CUBE_NAME  VARCHAR2(160) ,
  DIMENSION_NAME  VARCHAR2(160) ,
  DIMENSION_UNIQUE_NAME  VARCHAR2(160) ,
  DIMENSION_CAPTION  VARCHAR2(160) ,
  DIMENSION_ORDINAL VARCHAR2(160) ,
  DIMENSION_TYPE   VARCHAR2(160) ,
  DIMENSION_CARDINALITY VARCHAR2(160) ,
  DEFAULT_HIERARCHY  VARCHAR2(160) ,
  DESCRIPTION  VARCHAR2(160) ,
  DIMENSION_UNIQUE_SETTINGS  VARCHAR2(160) ,
  DIMENSION_IS_VISIBLE  VARCHAR2(160) 
 );
 
 TYPE DimensionList_T IS TABLE OF DimensionList_r; 
   
   
    TYPE essbaseMember_r IS RECORD
  (   CATALOG_NAME varchar2(160) ,
      CUBE_NAME varchar2(160) ,
      DIMENSION_UNIQUE_NAME varchar2(160) ,
      HIERARCHY_UNIQUE_NAME varchar2(160) ,
      LEVEL_UNIQUE_NAME varchar2(160) ,
      LEVEL_NUMBER  varchar2(160) ,
      GENERATION_NUMBER varchar2(160) ,
      MEMBER_ORDINAL varchar2(160)  ,
      MEMBER_NAME varchar2(160) ,
      MEMBER_UNIQUE_NAME varchar2(160) ,
      MEMBER_TYPE varchar2(160) ,
      MEMBER_CAPTION varchar2(160) ,
      CHILDREN_CARDINALITY varchar2(160) ,
      PARENT_LEVEL varchar2(160) ,
      PARENT_UNIQUE_NAME varchar2(160) ,
      PARENT_NAME varchar2(160) ,
      PARENT_COUNT varchar2(160) ,
      somes varchar2(160)   
  );
  
   TYPE essbaseHierarshi_T IS TABLE OF essbaseMember_r; 
   
   TYPE vCharValue_r IS RECORD
  ( vCharValue  VARCHAR2(31600)  
    );
    
   Type vCharValue_t Is Table Of vCharValue_r; 
 

  
  FUNCTION getXmlaData   ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2 )
        RETURN  vCharValue_t 
         parallel_enable  PIPELINED ;
 
  
   FUNCTION getMdxValueColumn  (  vMdxQuery VARCHAR2,vApsConnect VARCHAR2,vEsbConnect VARCHAR2 ) RETURN essbaseCrossJoin_t
      parallel_enable  PIPELINED ;
 
      
  FUNCTION getDimensionList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2 )        RETURN DimensionList_T 
         parallel_enable PIPELINED ;
         
   FUNCTION getApplications (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2  ) RETURN AppName_T   parallel_enable  PIPELINED ;       
  
  FUNCTION getDataBase (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2, vApplicationName VARCHAR2  ) RETURN cubeName_T   parallel_enable  PIPELINED ;
  
   FUNCTION getHierarshyList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN vCharValue_t 
  parallel_enable  PIPELINED ;
  
  
   FUNCTION getHierarshyMembersList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN essbaseHierarshi_T
  parallel_enable  PIPELINED ;
  
    FUNCTION getHierarshyByLevel  (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN levelHierarshi_T
  parallel_enable  PIPELINED ;      
  
end xmla_get_data_PKG;

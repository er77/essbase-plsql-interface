﻿create or replace
PACKAGE BODY xmla_get_data_PKG AS

 
 
FUNCTION getMdxValue  (  vMdxQuery VARCHAR2,vApsConnect VARCHAR2,vEsbConnect VARCHAR2 ) RETURN  varchar2_table
    PIPELINED AS
--PRAGMA AUTONOMOUS_TRANSACTION;    
vTextBuffer     VARCHAR2(32767);
vUtlHttpReq     UTL_HTTP.req;
vUtlHttpResp    UTL_HTTP.resp;
vUtlHttpConnRecord UTL_HTTP.connection;  
  i number ;
 vClobBuffer VARCHAR2(32767); 
 vPos number :=0;
 vPos2 number :=0; 
 vStrBuff VARCHAR2(32767);
 
 vIsEndOfHttp number :=0;
  BEGIN 
  UTL_HTTP.SET_DETAILED_EXCP_SUPPORT (true);
   BEGIN 
      utl_http.set_persistent_conn_support(true,4);
     
  vTextBuffer:='<?xml version="1.0" encoding="windows-1251"?><SOAP-ENV:Envelope
                              xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                              xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
                              xmlns:xsd="http://www.w3.org/2001/XMLSchema">
                              <SOAP-ENV:Body>
                              <Execute xmlns="urn:schemas-microsoft-com:xml-analysis"
                              SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
                              <Command>
<Statement>' ||vMdxQuery||'</Statement>
	 	 	 	 	 	 </Command>
	 	 	 	 	 	 <Properties>
	 	 	 	 	 	 <PropertyList>
	 	 	 	 	 	 <DataSourceInfo> Provider=Essbase;Data Source='||vEsbConnect||' </DataSourceInfo>
	 	 	 	<Content>Data</Content>
	 	 	 	 	 	 <Format>Tabular</Format>
	 	 	 	 	 	 <AxisFormat>TupleFormat</AxisFormat>
	 	 	 	 	 	 <Timeout>30000</Timeout>
	 	 	 	 	 	 </PropertyList>
	 	 	 	 	 	 </Properties>
	 	 	 	 	 	 </Execute>
	 	 	 	 	 	 </SOAP-ENV:Body>
	 	 	 	 	 	 </SOAP-ENV:Envelope>' ; 
             
 --  vUtlHttpConnRecord.host:='localhost';
    vIsEndOfHttp := 0;
    vUtlHttpReq := UTL_HTTP.begin_request(vApsConnect, 'POST');--, 'HTTP/1.0');
     utl_http.set_persistent_conn_support(vUtlHttpReq, TRUE);    
        UTL_HTTP.set_header(vUtlHttpReq, 'content-type', 'text/xml; charset=windows-1251');       
          UTL_HTTP.set_header(vUtlHttpReq, 'content-length', LENGTH(vTextBuffer));
          UTL_HTTP.write_text(vUtlHttpReq, vTextBuffer);
          UTL_HTTP.set_transfer_timeout(780000);
          
          vUtlHttpResp := UTL_HTTP.get_response(vUtlHttpReq);
 
        EXCEPTION
           WHEN OTHERS  THEN
                      vIsEndOfHttp := 1;
                      --XMLA_UTIL.srvWriteError (SQLCODE,vMdxQuery||'111  '||SQLERRM) ;  
                      --XMLA_UTIL.srvWriteError (utl_http.get_detailed_sqlcode,utl_http.get_detailed_sqlerrm) ;                        
          end;     
       if ( UTL_HTTP.HTTP_OK = vUtlHttpResp.status_code )  then       
             BEGIN  
                   UTL_HTTP.read_text(vUtlHttpResp, vTextBuffer, 20000); 
                   -- dbms_output.put_line(vTextBuffer);
               EXCEPTION
                  WHEN OTHERS THEN
                    vIsEndOfHttp := 1;  
               END;
            vClobBuffer:=vTextBuffer;
              vPos :=  instr (vClobBuffer,'row>',1,1);
                i  :=1;                
                   While( vPos != 0 ) loop 
                   IF (mod(i,2) = 0)     THEN
                       vTextBuffer := substr (vClobBuffer,1,vPos-2); 
                       vTextBuffer :=replace( replace(replace(vTextBuffer,CHR(13)),CHR(10)),'><');   
  
                        vPos2 := instr (vTextBuffer,'>',1,1);
                        vStrBuff :='';
                           While( vPos2 != 0 ) loop              
                               vTextBuffer := substr ( vTextBuffer,vPos2+1, length(vTextBuffer));               
                               vStrBuff := vStrBuff || replace(substr (vTextBuffer,1, instr (vTextBuffer,'<',1,1)-1),';','') || ';';                          
                               vPos2 := instr (vTextBuffer,'>',1,1);                             
                           end loop; 
                               PIPE ROW (vStrBuff);                              
                    END IF;   
                         vClobBuffer :=  SubStr(vClobBuffer,vPos+4,length(vClobBuffer));                             
                         vPos :=  instr(vClobBuffer,'row>',1,1);
                          if (0 = vPos)   then                            
                             if 0 = vIsEndOfHttp  then 
                                   BEGIN   
                                    UTL_HTTP.read_text(vUtlHttpResp, vTextBuffer, 20000); 
                                   EXCEPTION
                                       WHEN OTHERS THEN
                                        if sqlcode <> -29266 then  
                                          raise;  
                                        end if;                                     
                                          vIsEndOfHttp := 1;                                   
                                   END;  
                              end if;
                           vClobBuffer:=vClobBuffer||vTextBuffer;
                           vPos :=  instr(vClobBuffer,'row>',1,1);
                           
                          end if;
                         i := i+1;         
                   end loop;
     end if;
     UTL_HTTP.CLOSE_PERSISTENT_CONN (vUtlHttpConnRecord); 
     UTL_HTTP.END_RESPONSE (vUtlHttpResp);

EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
      UTL_HTTP.END_RESPONSE (vUtlHttpResp);
       return;
   WHEN  NO_DATA_NEEDED THEN      
      UTL_HTTP.END_RESPONSE (vUtlHttpResp);
      return;
   WHEN  OTHERS THEN
     
        if (sqlcode <> -29261 ) or (sqlcode <> -29266) then
        --   XMLA_UTIL.srvWriteError (SQLCODE,vMdxQuery||'    '||SQLERRM) ;       
        --   XMLA_UTIL.srvWriteError (utl_http.get_detailed_sqlcode,utl_http.get_detailed_sqlerrm) ; 
               RAISE;
        end if;       
END getMdxValue ;


END xmla_get_data_PKG;
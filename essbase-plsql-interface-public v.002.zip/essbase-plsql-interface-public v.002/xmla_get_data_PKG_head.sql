﻿create or replace
package xmla_get_data_PKG is
  
 Type varchar2_table Is Table Of varchar2(3200);   
  FUNCTION getMdxValue (vMdxQuery VARCHAR2,vApsConnect VARCHAR2,vEsbConnect VARCHAR2 ) RETURN  varchar2_table PIPELINED ;
   
 
  
end xmla_get_data_PKG;
﻿create or replace
package xmla_get_metadata  is

  Type varchar2_table Is Table Of varchar2(3200); 
     
  FUNCTION getXmlaData   ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 )
        RETURN  varchar2_table 
         parallel_enable PIPELINED ;
          
  FUNCTION getDimensionList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2 )        RETURN  varchar2_table 
         parallel_enable PIPELINED ;
         
   FUNCTION getApplications (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2  ) RETURN  varchar2_table
  parallel_enable  PIPELINED ;       
  
  
   FUNCTION getDataBase (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2, vApplicationName VARCHAR2  ) RETURN  varchar2_table
  parallel_enable  PIPELINED ;
  
   FUNCTION getHierarshyList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN  varchar2_table
  parallel_enable  PIPELINED ;
  
  
   FUNCTION getHierarshyMembersList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN  varchar2_table
  parallel_enable  PIPELINED ;

/*
  select * from ( table ( xmla_get_metadata_pkg.getDimensionList('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'sample' ,  'basic' ) )) ; 
  
  select * from ( table ( xmla_get_metadata_pkg.getApplications('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1'   ) )) ; 
 
  select * from ( table ( xmla_get_metadata_pkg.getDataBase('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'Sample'  ) )) ; 
  
  select * from ( table ( xmla_get_metadata_pkg.getHierarshyMembersList('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'sample' ,  'basic','year' ) )) ;  
   
  
*/
  
end xmla_get_metadata ;
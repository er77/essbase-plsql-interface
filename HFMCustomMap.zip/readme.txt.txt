
USE [EPM_HFM]
GO
ALTER DATABASE [EPM_HFM] SET TRUSTWORTHY ON ;
go
 
 drop function  [GetCustomID];
 drop assembly [HFMCustomMap];
 
 CREATE ASSEMBLY [HFMCustomMap] AUTHORIZATION [dbo] FROM  'E:\WorkFolder\_DiXY\HPL\CodeProgramm\HFMCustomMap\HFMCustomMap.dll'
WITH PERMISSION_SET = UNSAFE
 GO
 
CREATE FUNCTION [dbo].[GetCustomID](@vSourceValue [bigint], @vStartPos [smallint], @vLengthValue [smallint])
RETURNS [int] WITH EXECUTE AS CALLER
AS 
EXTERNAL NAME [HFMCustomMap].[UserDefinedFunctions].[GetCustomID]
GO
 
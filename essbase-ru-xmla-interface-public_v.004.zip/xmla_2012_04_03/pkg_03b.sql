﻿create or replace
PACKAGE BODY XMLA.XMLA_JOB_MANAGER_PKG AS

 vIsErrorRaised NUMBER := 0;
 vMessagesCount NUMBER := 0;
 
   TYPE connectPool_r IS RECORD
  (	vApsServer  VARCHAR2(300 CHAR), 
  	vEsbServer  VARCHAR2(300 CHAR), 
	  vUserName   VARCHAR2(300 CHAR), 
	  vPassowrd   VARCHAR2(300 CHAR)
    );
 
 TYPE connectPool_t IS TABLE of connectPool_r; 
 
 
  procedure  runJob( vMdxQuery   VARCHAR2    ,vApsConnect VARCHAR2,vEsbConnect VARCHAR2, vJobIDIN number  )  as 
  PRAGMA AUTONOMOUS_TRANSACTION;     
  vMdxHash  Number; 
  vJobIDOut Number ;
  vTimeHash TimeStamp;
  vPipeName varchar2(80);
  vPipeStatus Number;
  exit_now exception;
  vXmlaBody  VARCHAR2(32765);
  BEGIN 
  
   

vXmlaBody:='<?xml version="1.0" encoding="windows-1251"?><SOAP-ENV:Envelope
xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
xmlns:xsd="http://www.w3.org/2001/XMLSchema">
<SOAP-ENV:Body>
<Execute xmlns="urn:schemas-microsoft-com:xml-analysis"
SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<Command>
<Statement>' ||vMdxQuery||'</Statement>
</Command>
<Properties>
<PropertyList>
<DataSourceInfo> Provider=Essbase;Data Source='||vEsbConnect||' </DataSourceInfo>
<Content>Data</Content>
<Format>Tabular</Format>
<AxisFormat>TupleFormat</AxisFormat>
<Timeout>30000</Timeout>
</PropertyList>
</Properties>
</Execute>
</SOAP-ENV:Body>
</SOAP-ENV:Envelope>' ; 
 
   XMLA_UTIL_PKG.sendAlertSignal (vJobIDIN,  1  ); 
   
   XMLA_UTIL_PKG.waitFreeEssbaseConnect (vEsbConnect) ; 
   
     vJobIDOut:= xmla_get_data_PKG.createCache( vXmlaBody, vApsConnect, vJobIDIN ) ;  
    
   XMLA_UTIL_PKG.sendAlertSignal (vJobIDIN,  vJobIDOut  );

      XMLA_UTIL_PKG.setUnlockEssbaseConect (  vEsbConnect ) ; 
    commit;
  
EXCEPTION 
    when others then  
      update XX_XMLA_JOB_MONITOR set ISERROR = '-1'  where job_id  = vJobIDIN  ; -- set Label for display error 
       commit;
      XMLA_UTIL_PKG.srvWriteError ('runJob  '||SQLCODE,' vJobId :'|| vJobIDIN ||CHR(10)|| SQLERRM) ; 
      
      XMLA_UTIL_PKG.sendAlertSignal (vJobIDIN,  -1  );
      XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
      XMLA_UTIL_PKG.setUnlockEssbaseConect (  vEsbConnect ) ; 
   -- RAISE; 
  END runJob;
  

 function getConnectionPool return connectPool_t as
   PRAGMA AUTONOMOUS_TRANSACTION;  
   arrConnectPool connectPool_t:=connectPool_t();
   i number;
  begin
  i:=0;
    for crPool in  (SELECT  * from XX_XMLA_CONECTION_POOL  ) loop 
       i := i +1 ;
      arrConnectPool.EXTEND;
      arrConnectPool(i).vApsServer := crPool.APS_SERVER;
      arrConnectPool(i).vEsbServer := crPool.ESB_SERVER;
      arrConnectPool(i).vUserName  := crPool.USERNAME;
      arrConnectPool(i).vPassowrd  := crPool."PASSWORD"; 
  end loop;
  
  return arrConnectPool;
    EXCEPTION 
    when others then         
      XMLA_UTIL_PKG.srvWriteError ('getConnectionPool  '||SQLCODE, SQLERRM) ; 
      XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
  end ;
  
   
 
  FUNCTION getDataFromJobSeq  ( vMdxQuery   VARCHAR2, vFindString VARCHAR2   ,vReplaceStringArray VARCHAR2 ,vTypeOfStrings VARCHAR2 DEFAULT 'list' ) RETURN XMLA_UTIL_PKG.essbaseCrossJoin_T   parallel_enable PIPELINED as
  PRAGMA AUTONOMOUS_TRANSACTION;  
  
  vJobThreadCount number;
    vPos number;
  exit_now exception;
  vTextBuffer Varchar2(3200);
  
  vJobId Number;
  vJobSeq Number;
  --vCurrJobRunning  Varchar2(3200);
  
   TYPE tempcurtyp_curr IS REF CURSOR;
   vSqlTmpCursor tempcurtyp_curr;
   
    vJobRes XX_XMLA_JOB_MONITOR%rowtype;  
    
    arrConnectPool connectPool_t;
 
 vI number; 
  vApsConnect VARCHAR2(1000); 
  
  TYPE mdxParameters_t IS TABLE of varchar2(80); 
 arrMdxParameters mdxParameters_t:=mdxParameters_t();
 
 vJ number; 
 
 vBigLoop number;
 vCurrJobName  number; 
   
vCurrRecord XMLA_UTIL_PKG.essbaseCrossJoin_r ;
 
  i number;
  jobCount number;
   
  BEGIN
    -- XMLA_UTIL_PKG.holdInMemory(  'XMLA.XX_XMLA_CACHE' );
     
  arrConnectPool := getConnectionPool();
  
  vJ:=0;
   if 'list' = vTypeOfStrings then    
        vTextBuffer :=vReplaceStringArray;           
        vPos:=  instr (vTextBuffer,',',1,1);
         While( vPos != 0 ) loop 
          vJ:=vJ+1;
          arrMdxParameters.EXTEND;
          arrMdxParameters(vJ):=substr (vTextBuffer,1,vPos-1); 
          vTextBuffer:=SubStr(vTextBuffer,vPos+1,length(vTextBuffer));                                       
          vPos :=  instr(vTextBuffer,',',1,1);  
       end loop ; 
     else 
       OPEN vSqlTmpCursor FOR vReplaceStringArray ;
        LOOP
        FETCH vSqlTmpCursor INTO vTextBuffer;
         EXIT WHEN vSqlTmpCursor%NOTFOUND;
          vJ:=vJ+1;
          arrMdxParameters.EXTEND;
          arrMdxParameters(vJ):=vTextBuffer; 
        END LOOP; 
   end if;  
   
       vJobThreadCount := 0;   
       vJ :=0;
       vBigLoop :=1 ;
       jobCount :=0;
       --vCurrJobRunning :='';
       vJobSeq  := XMLA_UTIL_PKG.getJobNumber; 
  while 0 <  vBigLoop loop 
  
      while ( arrMdxParameters.count  > vJ ) LOOP 
      vI := 0;
         while ( XMLA_UTIL_PKG.vThreadCount > vI ) and ( arrMdxParameters.count > vJ ) LOOP 
                    vI:= vI+1;                  
                    vJ:= vJ+1; 
                      vJobThreadCount := vJobThreadCount +1;  
                        
                     vApsConnect := 'http://'||arrConnectPool(vI).vUserName||':'||arrConnectPool(vI).vPassowrd||'@'||arrConnectPool(vI).vApsServer; 
                     vJobId  := XMLA_UTIL_PKG.getJobNumber; 
                     XMLA_UTIL_PKG.registerAlert (vJobSeq,vJobId);                   
                    XMLA_UTIL_PKG.dbmsCreateJob ( 'j'||vJobId , 'XMLA_JOB_MANAGER_PKG.runJob('''||replace(vMdxQuery,vFindString,arrMdxParameters(vJ))||''','''|| vApsConnect||''','''|| arrConnectPool(vI).vEsbServer||''','''||vJobId ||''')' ) ;
                  --  dbms_output.put_line   (  'XMLA_JOB_MANAGER_PKG.runJob('''||replace(vMdxQuery,vFindString,arrMdxParameters(vJ))||''','''|| vApsConnect||''','''|| arrConnectPool(vI).vEsbServer||''','''||vJobId ||''')' ) ;

         end loop ; 
       --  XMLA_UTIL_PKG.dbmsSleep (  0.1 ) ;
   END LOOP;   -- while ( arrMdxParameters.count  > vJ ) LOOP
       
      vCurrJobName :='';
      vTextBuffer :='';
      vPos:=1;     
 
       XMLA_UTIL_PKG.waitAnyAlert(vJobSeq,vCurrJobName );  
       if ( vCurrJobName is not null ) then 
       -- dbms_output.put_line(vCurrJobName||vTextBuffer);
       if (0 > vCurrJobName ) then 
          XMLA_UTIL_PKG.srvWriteError ('Error in thread' || vCurrJobName,'') ;
       raise exit_now;
       end if;  
                
               vJobThreadCount:=vJobThreadCount-1;
               -- vCurrJobRunning:=replace(vCurrJobRunning,vCurrJobName||',');
                 XMLA_UTIL_PKG.removeAlert(vJobSeq,vCurrJobName);
                  --  dbms_output.put_line ( vCurrJobName );
                
                  for cJobResult in  (SELECT  XMLA_STRING FROM  XX_XMLA_cache where Job_ID  =  vCurrJobName and XMLA_STRING is not null ) loop 
                   -- PIPE ROW (cJobResult.XMLA_STRING);  
                   
                    vTextBuffer:=';'||substr(cJobResult.XMLA_STRING,1,length(cJobResult.XMLA_STRING)-1);
                 --  vTextBuffer:= cJobResult.XMLA_STRING ;
                   -- dbms_output.put_line(vStr);
                     vPos :=  instr (vTextBuffer,';',-1,1);
                    
                     vCurrRecord.DblValue :=  to_number( replace(substr(vTextBuffer,vPos+1,length(vTextBuffer)),',','.'),'9999999999999999.999999999');
                     vTextBuffer :=substr(vTextBuffer,1,vPos-1); 
                      vPos :=  instr (vTextBuffer,';',-1,1);
                        i := 22; 
                       -- dbms_output.put_line(vPos); 
                        While( vPos != 0 ) loop 
                            vApsConnect:=substr(vTextBuffer,vPos+1,length(vTextBuffer));
                          --   dbms_output.put_line(vApsConnect);
                         --     dbms_output.put_line(vTextBuffer);
                            i := i-1; 
                            vTextBuffer :=substr(vTextBuffer,1,vPos-1);                           
                            vPos :=  instr (vTextBuffer,';',-1,1);
                              if 21 = i then 
                               vCurrRecord.dim21:=vApsConnect;
                              end if;
                              if 20 = i then 
                               vCurrRecord.dim20:=vApsConnect;
                              end if;
                              if 19 = i then 
                               vCurrRecord.dim19:=vApsConnect;
                              end if;
                              if 18 = i then 
                               vCurrRecord.dim18:=vApsConnect;
                              end if;
                              if 17 = i then 
                               vCurrRecord.dim17:=vApsConnect;
                              end if;
                              if 16 = i then 
                               vCurrRecord.dim16:=vApsConnect;
                              end if;
                              if 15 = i then 
                               vCurrRecord.dim15:=vApsConnect;
                              end if;
                              if 14 = i then 
                               vCurrRecord.dim14:=vApsConnect;
                              end if;
                              if 13 = i then 
                               vCurrRecord.dim13:=vApsConnect;
                              end if;
                              if 12 = i then 
                               vCurrRecord.dim12:=vApsConnect;
                              end if;
                              if 11 = i then 
                               vCurrRecord.dim11:=vApsConnect;
                              end if;
                              if 10 = i then 
                               vCurrRecord.dim10:=vApsConnect;
                              end if;
                              if 9 = i then 
                               vCurrRecord.dim09:=vApsConnect;
                              end if;
                              if 8 = i then 
                               vCurrRecord.dim08:=vApsConnect;
                              end if;
                              if 7 = i then 
                               vCurrRecord.dim07:=vApsConnect;
                              end if;
                              if 6 = i then 
                               vCurrRecord.dim06:=vApsConnect;
                              end if;
                              if 5 = i then 
                               vCurrRecord.dim05:=vApsConnect;
                              end if;
                              if 4 = i then 
                               vCurrRecord.dim04:=vApsConnect;
                              end if;
                               if 3 = i then 
                               vCurrRecord.dim03:=vApsConnect;
                              end if;
                               if 2 = i then 
                               vCurrRecord.dim02:=vApsConnect;
                              end if;
                              if 1 = i then 
                               vCurrRecord.dim01:=vApsConnect;
                              end if;                              
                       end loop;     --While( vPos != 0 ) loop                          
                         PIPE ROW (vCurrRecord); 
                   
                 end loop; --for cJobResult in  (SELECT  XMLA_STRING FROM  XX_XMLA_cache where Job_ID  =  vCurrJobName and XMLA_STRING is not null ) loop 
              end if ;
     vBigLoop := vJobThreadCount;  
   -- dbms_output.put_line ( vBigLoop ); 
END LOOP;  
 
  
 EXCEPTION 
   WHEN NO_DATA_FOUND THEN 
    return;
   WHEN  NO_DATA_NEEDED THEN    
      return;
   when exit_now then       
       XMLA_UTIL_PKG.srvWriteError ('runJobSeq  exit_now'||SQLCODE, SQLERRM) ;   
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE;
    
    when others then 
       XMLA_UTIL_PKG.srvWriteError ('runJobSeq  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
      
    RAISE;   
END ;  

END XMLA_JOB_MANAGER_PKG;
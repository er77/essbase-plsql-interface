﻿create or replace
PACKAGE BODY      XMLA.xmla_get_data_PKG AS

 
FUNCTION getXmlaData  ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2  ) RETURN  XMLA_UTIL_PKG.varchar2_table
  parallel_enable  PIPELINED AS
PRAGMA AUTONOMOUS_TRANSACTION;    
vTextBuffer     VARCHAR2(32767);
vUtlHttpReq     UTL_HTTP.req;
vUtlHttpResp    UTL_HTTP.resp;
vUtlHttpConnRecord UTL_HTTP.connection;  
  i number ;
 vClobBuffer VARCHAR2(32767); 
 vPos number :=0;
 vPos2 number :=0; 
 vStrBuff VARCHAR2(32767);
 
 vIsEndOfHttp number :=0;
 vXMLAHash number;
 vJobIDOut number;
 vRowCount number;
 vTimeHash TimeStamp;
 
  BEGIN 
 
-- check fo cache 
if 1 = XMLA_UTIL_PKG.vIsEssbaseCachable then  
vXMLAHash :=0;
 vXMLAHash := XMLA_UTIL_PKG.getHash(vXmlaBody );  
vJobIDOut :=0;
vTimeHash :=sysdate ;
   for cr in ( select nvl(JOB_ID,0) JOB_ID,nvl(XMLA_STATEMENT,'dd') XMLA_STATEMENT,time_creation  from XX_XMLA_JOB_MONITOR where  Xmla_HASH  = vXMLAHash and ISERROR = 0 ) loop
  
    if( cr.xmla_STATEMENT like vXmlaBody ) then  -- get decision for hash collision 
      vJobIDOut:=cr.JOB_ID;
      vTimeHash:=cr.time_creation;
    end if;    
  
   end loop;  
  --  dbms_output.put_line (2);
  if (  0 < vJobIDOut )  then -- ALREDY CALCULATED  
     if vTimeHash < ( sysdate - XMLA_UTIL_PKG.vTimeToLeaveCahce ) then 
       XMLA_UTIL_PKG.runDeleteCacheForJob( vJobIDOut );       
      else
      --dbms_output.put_line (vJobIDIN||vJobIDOut);
        for cJobResult in  (SELECT  XMLA_STRING FROM  XX_XMLA_cache where Job_ID  =  vJobIDOut and XMLA_STRING is not null ) loop 
          PIPE ROW (cJobResult.XMLA_STRING); 
        end loop;      
         return ; -- exit from xmla_cache 
      end if ;  
  end if ; 
 -- dbms_output.put_line (3);
end if;   -- end of check cache 
-- prepare job logs
   

  UTL_HTTP.set_transfer_timeout(2147483647);
  UTL_HTTP.SET_DETAILED_EXCP_SUPPORT (false);
  utl_http.set_response_error_check( false); 
 
    --  utl_http.set_persistent_conn_support(true,4);  
 --  vUtlHttpConnRecord.host:='localhost';
    vIsEndOfHttp := 0;
  -- dbms_output.put_line ('v1'); 
   
    vUtlHttpReq := UTL_HTTP.begin_request(trim(vApsConnect), 'POST');--, 'HTTP/1.0');
    -- utl_http.set_persistent_conn_support(vUtlHttpReq, TRUE); 
    vTextBuffer:=trim(vXmlaBody);
          UTL_HTTP.set_header(vUtlHttpReq, 'content-type', 'text/xml; charset=windows-1251'); 
          utl_http.set_header(vUtlHttpReq, 'user-agent', 'mozilla/4.0'); 
          UTL_HTTP.set_header(vUtlHttpReq, 'content-length', LENGTH(vTextBuffer));
          begin 
            UTL_HTTP.write_text(vUtlHttpReq, '');
            EXCEPTION  
              WHEN  OTHERS THEN  
               null;
          end;     
          UTL_HTTP.write_text(vUtlHttpReq, vTextBuffer);
         
          vUtlHttpResp := UTL_HTTP.get_response(vUtlHttpReq);
        
       if ( UTL_HTTP.HTTP_OK = vUtlHttpResp.status_code )  then   
     --  dbms_output.put_line ('v4'); 
             BEGIN  
                   UTL_HTTP.read_text(vUtlHttpResp, vTextBuffer, 20000); 
                     
                    if 1 = XMLA_UTIL_PKG.vIsDebugSOA then 
                       XMLA_UTIL_PKG.srvWriteError ('',vTextBuffer) ;
                    end if;   
                    
               EXCEPTION
                  WHEN OTHERS THEN
                    vIsEndOfHttp := 1;  
               END;
  --  dbms_output.put_line ('v3');           
            vClobBuffer:=vTextBuffer;
              vPos :=  instr (vClobBuffer,'row>',1,1);
                i  :=1;                
                   While( vPos != 0 ) loop 
                   IF (mod(i,2) = 0)     THEN
                       vTextBuffer := substr (vClobBuffer,1,vPos-2); 
                       vTextBuffer :=replace( replace(replace(vTextBuffer,CHR(13)),CHR(10)),'><');   
  
                        vPos2 := instr (vTextBuffer,'>',1,1);
                        vStrBuff :='';
                           While( vPos2 != 0 ) loop              
                               vTextBuffer := substr ( vTextBuffer,vPos2+1, length(vTextBuffer));               
                               vStrBuff := vStrBuff || replace(substr (vTextBuffer,1, instr (vTextBuffer,'<',1,1)-1),';','') || ';';                          
                               vPos2 := instr (vTextBuffer,'>',1,1);                             
                           end loop; 
                               PIPE ROW (vStrBuff);  
                               vRowCount:=vRowCount+1;
                    END IF;   
                         vClobBuffer :=  SubStr(vClobBuffer,vPos+4,length(vClobBuffer));                             
                         vPos :=  instr(vClobBuffer,'row>',1,1);
                          if (0 = vPos)   then                            
                             if 0 = vIsEndOfHttp  then 
                                   BEGIN   
                                    UTL_HTTP.read_text(vUtlHttpResp, vTextBuffer, 20000); 
      --   dbms_output.put_line ('v3');                               
                                  if 1 = XMLA_UTIL_PKG.vIsDebugSOA then 
                                     XMLA_UTIL_PKG.srvWriteError ('',vTextBuffer) ;                                  
                                  end if; 
                                  
                                   EXCEPTION
                                       WHEN OTHERS THEN
                                        if sqlcode <> -29266 then  
                                          raise;  
                                        end if;                                     
                                          vIsEndOfHttp := 1;                                   
                                   END;  
                              end if;
                           vClobBuffer:=vClobBuffer||vTextBuffer;
                           vPos :=  instr(vClobBuffer,'row>',1,1);
                           
                          end if;
                         i := i+1;         
                   end loop;
     end if;

if   1 = vIsEndOfHttp then 
  UTL_HTTP.END_RESPONSE (vUtlHttpResp);
end if;
-- ctreate cache 
if 1 = XMLA_UTIL_PKG.vIsEssbaseCachable then  
 XMLA_UTIL_PKG.dbmsCreateJob ( 'j'||XMLA_UTIL_PKG.getJobNumber , 'xmla_get_data_PKG.runCreateCache('''|| vXmlaBody ||''','''|| vApsConnect||''','''|| XMLA_UTIL_PKG.getJobNumber ||''')' ) ;
end if;

EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
      UTL_HTTP.END_RESPONSE (vUtlHttpResp);
  
       return;
   WHEN  NO_DATA_NEEDED THEN      
      UTL_HTTP.END_RESPONSE (vUtlHttpResp);
    
      return;
   WHEN  OTHERS THEN   
       
        if (sqlcode <> -29261 ) or (sqlcode <> -29266) then
               
           XMLA_UTIL_PKG.srvWriteError  (utl_http.get_detailed_sqlcode,utl_http.get_detailed_sqlerrm) ; 
           XMLA_UTIL_PKG.srvWriteError  ('Error Detail ',DBMS_UTILITY.format_error_backtrace) ;
           XMLA_UTIL_PKG.srvWriteError ('vTextBuffer ', vTextBuffer) ;
           XMLA_UTIL_PKG.srvWriteError  ('vApsConnect ', vApsConnect) ; 
          RAISE;
        end if;        
END getXmlaData ;

procedure runCreateCache ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2, vJobIdIN number  ) as
PRAGMA AUTONOMOUS_TRANSACTION;   
vR number;
begin 
 vR:=xmla_get_data_PKG.createCache ( vXmlaBody ,  vApsConnect , vJobIdIN   );
EXCEPTION   
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
  RAISE;  
end;

function  createCache  ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2, vJobIdIN number  ) return number as 
PRAGMA AUTONOMOUS_TRANSACTION;    

 vRowCount number;
 vXMLAHash number;
 vIsRunning number;
 vJobIdOut  number;
begin 

vJobIdOut:=0;
vXMLAHash:=0;
vXMLAHash:=XMLA_UTIL_PKG.getHash(vXmlaBody ); 

 for cr in ( select nvl(JOB_ID,0) JOB_ID,nvl(XMLA_STATEMENT,'dd') XMLA_STATEMENT , isError from XX_XMLA_JOB_MONITOR where  Xmla_HASH  = vXMLAHash  ) loop
  
     if( cr.xmla_STATEMENT like vXmlaBody ) then  -- get decision for hash collision 
      vJobIdOut:=cr.JOB_ID;
      vIsRunning:=cr.isError;
    end if;    
  
end loop;   
 
if 0 < vJobIdOut then  
 if 0=vIsRunning then 
  return vJobIdOut;
end if;
 --whait other process 
while 0 > vIsRunning loop
   XMLA_UTIL_PKG.dbmsSleep (  0.3 ) ;
   vIsRunning := 0;
  select isError into  vIsRunning from XX_XMLA_JOB_MONITOR where JOB_ID=vJobIdOut;
end loop;
return vJobIdOut;
end if;

     vRowCount :=0;
     
       insert INTO XX_XMLA_JOB_MONITOR   ( job_id, xmla_STATEMENT,  xmla_HASH ,isError )
           VALUES    (  vJobIdIN,vXmlaBody,vXMLAHash  , -1  );
       commit; 

        For crc In ( Select * From (Table( xmla_get_data_PKG.getXmlaData(vXmlaBody,vApsConnect ) )  ) )  Loop   
         INSERT INTO XX_XMLA_CACHE  (XMLA_STRING, JOB_ID )  VALUES  (crc.COLUMN_VALUE, vJobIdIN  );  
         vRowCount :=vRowCount+1;
      end loop;
    
    update XX_XMLA_JOB_MONITOR set RowCount=vRowCount,isError=0 where job_id=vJobIdIN;
     
    commit; 
return vJobIDOut;   
EXCEPTION   
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
  RAISE; 
end;


 FUNCTION getDimensionList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2 ) RETURN  XMLA_UTIL_PKG.DimensionList_T
  parallel_enable  PIPELINED AS
vTextBuffer     VARCHAR2(32765);
vCurrREcord XMLA_UTIL_PKG.DimensionList_r ;
vCurrText varchar2(80);
vPos Number;
i number;
  begin
    vTextBuffer:= '<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema">
 <SOAP-ENV:Body>
   <Discover xmlns="urn:schemas-microsoft-com:xml-analysis"
   SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
    <RequestType>MDSCHEMA_DIMENSIONS</RequestType>
    <Restrictions>
     <RestrictionList>
      <CATALOG_NAME>'||upper(vApplicationName)||'</CATALOG_NAME>
      <CUBE_NAME>'||upper(vDatabaseName)||'</CUBE_NAME>
     </RestrictionList>
    </Restrictions>
    <Properties>
     <PropertyList>
      <DataSourceInfo>Provider=Essbase;Data Source='||vEsbConnect||' </DataSourceInfo>
      <Format>Tabular</Format>
     </PropertyList>
    </Properties>
  </Discover>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>' ;
       For crc In ( Select * From (Table( getXmlaData(vTextBuffer,vApsConnect ) )  ) )  Loop
              vTextBuffer:=';'||substr(crc.COLUMN_VALUE,1,length(crc.COLUMN_VALUE)-1);     
                      vPos :=  instr (vTextBuffer,';',-1,1);                    
                        i := 13;                      
                        While( vPos != 0 ) loop 
                            vCurrText:=substr(vTextBuffer,vPos+1,length(vTextBuffer));                            
                              if 12 = i then 
                               vCurrRecord.DIMENSION_IS_VISIBLE:=vCurrText;
                              end if;
                              if 11 = i then 
                               vCurrRecord.DIMENSION_UNIQUE_SETTINGS:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 6 = i then 
                               vCurrRecord.DESCRIPTION:=vCurrText;
                              end if;
                              if 10 = i then 
                               vCurrRecord.DEFAULT_HIERARCHY:=vCurrText;
                              end if;
                              if 9 = i then 
                               vCurrRecord.DIMENSION_CARDINALITY:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 8 = i then 
                               vCurrRecord.DIMENSION_TYPE:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 7 = i then 
                               vCurrRecord.DIMENSION_ORDINAL:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 5 = i then 
                               vCurrRecord.DIMENSION_CAPTION:=vCurrText;
                              end if;
                              if 4 = i then 
                               vCurrRecord.DIMENSION_UNIQUE_NAME:=vCurrText;
                              end if;
                              if 3 = i then 
                               vCurrRecord.DIMENSION_NAME:=vCurrText;
                              end if;
                               if 2 = i then 
                               vCurrRecord.CUBE_NAME:=substr(vCurrText,instr(vCurrText,'.')+1,length(vCurrText));
                              end if;
                               if 1 = i then 
                               vCurrRecord.CATALOG_NAME:=vCurrText;
                              end if;
                                i := i-1;   
                    vTextBuffer :=substr(vTextBuffer,1,vPos-1);                           
                    vPos :=  instr (vTextBuffer,';',-1,1);       
                       end loop;  
           PIPE ROW (vCurrRecord); 
    end loop;
EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
        return;
   WHEN  NO_DATA_NEEDED THEN 
        return;
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
            XMLA_UTIL_PKG.srvWriteError  ('vTextBuffer' , vTextBuffer) ;
            XMLA_UTIL_PKG.srvWriteError  ('vApsConnect' ,  vApsConnect) ; 
          RAISE;
   
END getDimensionList ; 
 
 FUNCTION getApplications (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2  ) RETURN  XMLA_UTIL_PKG.AppName_t
  parallel_enable  PIPELINED AS
vTextBuffer     VARCHAR2(32767);
vCurrREcord XMLA_UTIL_PKG.AppName_r ;
  begin
    vTextBuffer:= '<SOAP-ENV:Envelope  xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema">
 <SOAP-ENV:Body> 
  <Discover xmlns="urn:schemas-microsoft-com:xml-analysis" 
   SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
   <RequestType>DBSCHEMA_CATALOGS</RequestType>
   <Restrictions>
    <RestrictionList></RestrictionList>
   </Restrictions>
   <Properties>
    <PropertyList>
     <DataSourceInfo>Provider=Essbase;Data Source='||upper(vEsbConnect)||' </DataSourceInfo>
     <Format>Tabular</Format>
    </PropertyList>
   </Properties>
  </Discover>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>' ;
       For crc In ( Select * From (Table( getXmlaData(vTextBuffer,vApsConnect ) )  ) )  Loop
          vCurrREcord.AppName := substr(crc.COLUMN_VALUE,1,length(crc.COLUMN_VALUE)-1);
           PIPE ROW (vCurrREcord);
    end loop;
EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
        return;
   WHEN  NO_DATA_NEEDED THEN 
        return;
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
            XMLA_UTIL_PKG.srvWriteError  ('vTextBuffer' , vTextBuffer) ;
            XMLA_UTIL_PKG.srvWriteError  ('vApsConnect' ,  vApsConnect) ;  
          RAISE;
   
END getApplications ;  

 FUNCTION getDataBase (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2, vApplicationName VARCHAR2  ) RETURN XMLA_UTIL_PKG.cubeName_T
  parallel_enable  PIPELINED AS
vTextBuffer     VARCHAR2(32767);
vCurrRecord XMLA_UTIL_PKG.cubeName_r;
  begin
    vTextBuffer:= '<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema">
 <SOAP-ENV:Body>
  <Discover xmlns="urn:schemas-microsoft-com:xml-analysis"
   SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
   <RequestType>MDSCHEMA_CUBES</RequestType>
    <Restrictions>
     <RestrictionList>
	       <CATALOG_NAME>'||upper(vApplicationName)||'</CATALOG_NAME>
     </RestrictionList>
    </Restrictions>
    <Properties>
     <PropertyList>
      <DataSourceInfo>
       Provider=Essbase;Data Source='||upper(vEsbConnect)||' </DataSourceInfo>
      <Format>Tabular</Format>
     </PropertyList>
    </Properties>
   </Discover>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>' ;
       For crc In ( Select * From (Table( getXmlaData(vTextBuffer,vApsConnect ) )  ) )  Loop
              vCurrRecord.AppName :=substr(crc.COLUMN_VALUE,1,instr(crc.COLUMN_VALUE,';')-1);
              vCurrRecord.CubeName :=substr(crc.COLUMN_VALUE,instr(crc.COLUMN_VALUE,'.')+1,instr(substr(crc.COLUMN_VALUE,instr(crc.COLUMN_VALUE,'.')+1,length(crc.COLUMN_VALUE)),';')-1) ;
           PIPE ROW (vCurrRecord);
 
    end loop;
EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
        return;
   WHEN  NO_DATA_NEEDED THEN 
        return;
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
            XMLA_UTIL_PKG.srvWriteError  ('vTextBuffer' , vTextBuffer) ;
            XMLA_UTIL_PKG.srvWriteError  ('vApsConnect' ,  vApsConnect) ; 
          RAISE;
   
END getDataBase ;  


 FUNCTION getHierarshyList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN  XMLA_UTIL_PKG.varchar2_table
  parallel_enable  PIPELINED AS
vTextBuffer     VARCHAR2(32767);
  begin
    vTextBuffer:= '<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema">
 <SOAP-ENV:Body>
  <Discover xmlns="urn:schemas-microsoft-com:xml-analysis"
   SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
   <RequestType>MDSCHEMA_HIERARCHIES</RequestType>
    <Restrictions>
     <RestrictionList>
      <CUBE_NAME>'||upper(vApplicationName)||'.'||upper(vDatabaseName)||'</CUBE_NAME>
      <DIMENSION_UNIQUE_NAME>'||upper(vHierashiName)||'</DIMENSION_UNIQUE_NAME>
     </RestrictionList>
    </Restrictions>
    <Properties>
     <PropertyList>
      <DataSourceInfo>Provider=Essbase;Data Source=localhost
      </DataSourceInfo>
      <Format>Tabular</Format>
     </PropertyList>
	     </Properties>
   </Discover>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>' ;
       For crc In ( Select * From (Table( getXmlaData(vTextBuffer,vApsConnect ) )  ) )  Loop
 
           PIPE ROW (crc.COLUMN_VALUE);
 
    end loop;
EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
        return;
   WHEN  NO_DATA_NEEDED THEN 
        return;
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
            XMLA_UTIL_PKG.srvWriteError  ('vTextBuffer' , vTextBuffer) ;
            XMLA_UTIL_PKG.srvWriteError  ('vApsConnect' ,  vApsConnect) ; 
          RAISE;
   
END getHierarshyList ; 
  
 
 FUNCTION getHierarshyMembersList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN  XMLA_UTIL_PKG.essbaseHierarshi_T
  parallel_enable  PIPELINED AS
vTextBuffer     VARCHAR2(32767);
vCurrText       VARCHAR2(32767);
vCurrRecord      XMLA_UTIL_PKG.essbaseMember_r;

vPos number;
i number;

  begin
    vTextBuffer:= '<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema">
 <SOAP-ENV:Body>
  <Discover xmlns="urn:schemas-microsoft-com:xml-analysis"
   SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
   <RequestType>MDSCHEMA_MEMBERS</RequestType>
   <Restrictions>
    <RestrictionList>
     <CATALOG_NAME>'||upper(vApplicationName)||'</CATALOG_NAME>
     <CUBE_NAME>'||upper(vDatabaseName)||'</CUBE_NAME>
     <DIMENSION_UNIQUE_NAME>'||upper(vHierashiName)||'</DIMENSION_UNIQUE_NAME>
    </RestrictionList>
   </Restrictions>
   <Properties>
    <PropertyList>
     <DataSourceInfo>
      Provider=Essbase;Data Source='||upper(vEsbConnect)||' </DataSourceInfo>
     <Format>Tabular</Format>
    </PropertyList>
   </Properties>
  </Discover>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>' ;
--dbms_output.put_line(1);
       For crc In ( Select * From (Table( getXmlaData(vTextBuffer,vApsConnect ) )  ) )  Loop
 --dbms_output.put_line(2);         
       vTextBuffer:=';'||substr(crc.COLUMN_VALUE,1,length(crc.COLUMN_VALUE)-1);
      -- dbms_output.put_line(3);
                      vPos :=  instr (vTextBuffer,';',-1,1);
                    --  dbms_output.put_line('crc.COLUMN_VALUE'||crc.COLUMN_VALUE);
                        i := 18; 
                       -- dbms_output.put_line(vPos); 
                        While( vPos != 0 ) loop 
                            vCurrText:=substr(vTextBuffer,vPos+1,length(vTextBuffer));
                             -- dbms_output.put_line('vCurrText'||vCurrText);
                            i := i-1; 
                              if 17 = i then 
                               vCurrRecord.somes:=vCurrText;
                              end if;
                              if 16 = i then 
                               vCurrRecord.PARENT_COUNT:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 15 = i then 
                               vCurrRecord.PARENT_UNIQUE_NAME:=vCurrText;
                               vCurrRecord.PARENT_NAME:=replace(replace(vCurrText,']'),'[');
                              end if;
                              if 14 = i then 
                               vCurrRecord.PARENT_LEVEL:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 13 = i then 
                               vCurrRecord.CHILDREN_CARDINALITY:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 12 = i then 
                               vCurrRecord.MEMBER_CAPTION:=vCurrText;
                              end if;
                              if 11 = i then 
                               vCurrRecord.MEMBER_TYPE:=vCurrText;
                              end if;
                              if 10 = i then 
                               vCurrRecord.MEMBER_UNIQUE_NAME:=vCurrText;
                              end if;
                              if 9 = i then 
                               vCurrRecord.MEMBER_NAME:=vCurrText;
                              end if;
                              if 8 = i then 
                               vCurrRecord.MEMBER_ORDINAL:=vCurrText;
                              end if;
                              if 7 = i then 
                               vCurrRecord.GENERATION_NUMBER:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 6 = i then 
                               vCurrRecord.LEVEL_NUMBER:=to_number( replace(vCurrText,',','.'),'9999999999999999.999999999');
                              end if;
                              if 5 = i then 
                               vCurrRecord.LEVEL_UNIQUE_NAME:=vCurrText;
                              end if;
                              if 4 = i then 
                               vCurrRecord.HIERARCHY_UNIQUE_NAME:=vCurrText;
                              end if;
                               if 3 = i then 
                               vCurrRecord.DIMENSION_UNIQUE_NAME:=vCurrText;
                              end if;
                               if 2 = i then 
                               vCurrRecord.CUBE_NAME:=substr (vCurrText,instr(vCurrText,'.')+1,length(vCurrText));
                              end if;
                              if 1 = i then 
                               vCurrRecord.CATALOG_NAME:=vCurrText;
                              end if;   
                    vTextBuffer :=substr(vTextBuffer,1,vPos-1);                           
                    vPos :=  instr (vTextBuffer,';',-1,1);       
                       end loop;                            
                         PIPE ROW (vCurrRecord);   
    end loop;
EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
        return;
   WHEN  NO_DATA_NEEDED THEN 
        return;
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
            XMLA_UTIL_PKG.srvWriteError  ('vTextBuffer' , vTextBuffer) ;
            XMLA_UTIL_PKG.srvWriteError  ('vApsConnect' ,  vApsConnect) ; 
            XMLA_UTIL_PKG.srvWriteError  ('vCurrText' ,  vCurrText) ; 
            XMLA_UTIL_PKG.srvWriteError  ('i' ,  i) ; 
          RAISE;
   
END getHierarshyMembersList ; 


FUNCTION getMdxValue  (  vMdxQuery VARCHAR2,vApsConnect VARCHAR2,vEsbConnect VARCHAR2 ) RETURN XMLA_UTIL_PKG.essbaseCrossJoin_t
  parallel_enable  PIPELINED AS
 vTextBuffer     VARCHAR2(32767);
 vCurrText       VARCHAR2(32767);
vCurrRecord XMLA_UTIL_PKG.essbaseCrossJoin_r ;

vPos number;
i number;

   BEGIN  
  vTextBuffer:='<?xml version="1.0" encoding="windows-1251"?><SOAP-ENV:Envelope
xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
xmlns:xsd="http://www.w3.org/2001/XMLSchema">
<SOAP-ENV:Body>
<Execute xmlns="urn:schemas-microsoft-com:xml-analysis"
SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<Command>
<Statement>' ||upper(vMdxQuery)||'</Statement>
</Command>
<Properties>
<PropertyList>
<DataSourceInfo> Provider=Essbase;Data Source='||upper(vEsbConnect)||' </DataSourceInfo>
<Content>Data</Content>
<Format>Tabular</Format>
<AxisFormat>TupleFormat</AxisFormat>
<Timeout>30000</Timeout>
</PropertyList>
</Properties>
</Execute>
</SOAP-ENV:Body>
</SOAP-ENV:Envelope>' ;     

       For crc In ( Select * From (Table( getXmlaData(vTextBuffer,vApsConnect ) )  ) )  Loop
              
                    vTextBuffer:=';'||substr(crc.COLUMN_VALUE,1,length(crc.COLUMN_VALUE)-1);
 
                     vPos :=  instr (vTextBuffer,';',-1,1);
                    
                     vCurrRecord.DblValue :=  to_number( replace(substr(vTextBuffer,vPos+1,length(vTextBuffer)),',','.'),'9999999999999999.999999999');
                     vTextBuffer :=substr(vTextBuffer,1,vPos-1); 
                      vPos :=  instr (vTextBuffer,';',-1,1);
                        i := 22; 
 
                        While( vPos != 0 ) loop  
                            i := i-1; 
                            vTextBuffer :=substr(vTextBuffer,1,vPos-1);                           
                            vPos :=  instr (vTextBuffer,';',-1,1);
                               vCurrText:=substr(vTextBuffer,vPos+1,length(vTextBuffer));
                              if 21 = i then 
                               vCurrRecord.dim21:=vCurrText;
                              end if;
                              if 20 = i then 
                               vCurrRecord.dim20:=vCurrText;
                              end if;
                              if 19 = i then 
                               vCurrRecord.dim19:=vCurrText;
                              end if;
                              if 18 = i then 
                               vCurrRecord.dim18:=vCurrText;
                              end if;
                              if 17 = i then 
                               vCurrRecord.dim17:=vCurrText;
                              end if;
                              if 16 = i then 
                               vCurrRecord.dim16:=vCurrText;
                              end if;
                              if 15 = i then 
                               vCurrRecord.dim15:=vCurrText;
                              end if;
                              if 14 = i then 
                               vCurrRecord.dim14:=vCurrText;
                              end if;
                              if 13 = i then 
                               vCurrRecord.dim13:=vCurrText;
                              end if;
                              if 12 = i then 
                               vCurrRecord.dim12:=vCurrText;
                              end if;
                              if 11 = i then 
                               vCurrRecord.dim11:=vCurrText;
                              end if;
                              if 10 = i then 
                               vCurrRecord.dim10:=vCurrText;
                              end if;
                              if 9 = i then 
                               vCurrRecord.dim09:=vCurrText;
                              end if;
                              if 8 = i then 
                               vCurrRecord.dim08:=vCurrText;
                              end if;
                              if 7 = i then 
                               vCurrRecord.dim07:=vCurrText;
                              end if;
                              if 6 = i then 
                               vCurrRecord.dim06:=vCurrText;
                              end if;
                              if 5 = i then 
                               vCurrRecord.dim05:=vCurrText;
                              end if;
                              if 4 = i then 
                               vCurrRecord.dim04:=vCurrText;
                              end if;
                               if 3 = i then 
                               vCurrRecord.dim03:=vCurrText;
                              end if;
                               if 2 = i then 
                               vCurrRecord.dim02:=vCurrText;
                              end if;
                              if 1 = i then 
                               vCurrRecord.dim01:=vCurrText;
                              end if;                              
                       end loop;     --While( vPos != 0 ) loop                          
                         PIPE ROW (vCurrRecord); 
     end loop;
     
EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
        return;
   WHEN  NO_DATA_NEEDED THEN 
        return;
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
            XMLA_UTIL_PKG.srvWriteError  ('vTextBuffer' , vTextBuffer) ;
            XMLA_UTIL_PKG.srvWriteError  ('vApsConnect' ,  vApsConnect) ; 
          RAISE;      
END getMdxValue ;

    FUNCTION getHierarshyByLevel  (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN XMLA_UTIL_PKG.levelHierarshi_T
  parallel_enable  PIPELINED  as
  vTextBuffer     VARCHAR2(32767);
  
     TYPE currMember_r IS RECORD
  ( Generation_number  number ,
    member_name  VARCHAR2(80) ,
    parent_name  VARCHAR2(80)   
    );
  TYPE currDimension_T IS TABLE OF currMember_r; 
  
   arrDimension currDimension_T:=currDimension_T();
   vJ Number;
   vI Number;
   
  arrLevelHierarshi  XMLA_UTIL_PKG.levelHierarshi_T:=XMLA_UTIL_PKG.levelHierarshi_T() ;
 --  vCurrLevelNumber Number;
   --Generation_number,member_name,parent_name
   begin
   vJ:=0;
   
 /* cache dimension for looping */  
 
  for currDim in ( select * from ( table (  getHierarshyMembersList(vApsConnect , vEsbConnect ,vApplicationName ,  vDatabaseName,vHierashiName ) )))
      loop
          vJ:=vJ+1;
          arrDimension.EXTEND;
          arrDimension(vJ).Generation_number:= currDim.Parent_level+2;
          arrDimension(vJ).member_name:= replace(replace(currDim.member_name,'['),']');
          arrDimension(vJ).parent_name:= replace(replace(currDim.parent_name,'['),']');      
       end loop ;
       
  vI := 0;
  for  vCurrLevelNumber in REVERSE 1..22  loop
  
  if 0 = vI then 
      for j in 1..vJ loop
         if vCurrLevelNumber = arrDimension(j).Generation_number then 
            arrLevelHierarshi.EXTEND;
            vI:=vI+1;
           
                              if 21 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev21:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev20:=arrDimension(j).parent_name;
                              end if;
                              if 20 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev20:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev19:=arrDimension(j).parent_name;
                              end if;
                              if 19 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev19:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev18:=arrDimension(j).parent_name;
                              end if;
                              if 18 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev18:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev17:=arrDimension(j).parent_name;
                              end if;
                              if 17 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev17:=arrDimension(j).member_name;
				 arrLevelHierarshi(vI).lev16:=arrDimension(j).parent_name;
                              end if;
                              if 16 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev16:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev15:=arrDimension(j).parent_name;
                              end if;
                              if 15 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev15:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev14:=arrDimension(j).parent_name;
                              end if;
                              if 14 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev14:=arrDimension(j).member_name;
				 arrLevelHierarshi(vI).lev13:=arrDimension(j).parent_name;
                              end if;
                              if 13 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev13:=arrDimension(j).member_name;
				 arrLevelHierarshi(vI).lev12:=arrDimension(j).parent_name;
                              end if;
                              if 12 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev12:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev11:=arrDimension(j).parent_name;
                              end if;
                              if 11 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev11:=arrDimension(j).member_name;
				arrLevelHierarshi(vI).lev10:=arrDimension(j).parent_name;
                              end if;
                              if 10 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev10:=arrDimension(j).member_name;
				 arrLevelHierarshi(vI).lev09:=arrDimension(j).parent_name;
                              end if;
                              if 9 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev09:=arrDimension(j).member_name;
				 arrLevelHierarshi(vI).lev08:=arrDimension(j).parent_name;
                              end if;
                              if 8 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev08:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev07:=arrDimension(j).parent_name;
                              end if;
                              if 7 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev07:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev06:=arrDimension(j).parent_name;
                              end if;
                              if 6 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev06:=arrDimension(j).member_name;
				 arrLevelHierarshi(vI).lev05:=arrDimension(j).parent_name;
                              end if;
                              if 5 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev05:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev04:=arrDimension(j).parent_name;
                              end if;
                              if 4 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev04:=arrDimension(j).member_name;
				 arrLevelHierarshi(vI).lev03:=arrDimension(j).parent_name;
                              end if;
                               if 3 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev03:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev02:=arrDimension(j).parent_name;
                              end if;
                               if 2 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev02:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev01:=arrDimension(j).parent_name;
                              end if; 
                               if 1 = vCurrLevelNumber then 
                               arrLevelHierarshi(vI).lev01:=arrDimension(j).member_name;
				  arrLevelHierarshi(vI).lev01:=arrDimension(j).parent_name;
                              end if; 
                            
         end if ;
      end loop;
  else 
          for j in 1..vJ loop
             if vCurrLevelNumber = arrDimension(j).Generation_number then 
                    for i in 1..vI loop
                      
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev21 then 
                          arrLevelHierarshi(i).lev20 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev20 then 
                          arrLevelHierarshi(i).lev19 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev19 then 
                          arrLevelHierarshi(i).lev18 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev18 then 
                          arrLevelHierarshi(i).lev17 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev17 then 
                          arrLevelHierarshi(i).lev16 := arrDimension(j).parent_name;
                       end if;                       
			  if arrDimension(j).member_name like arrLevelHierarshi(i).lev16 then 
                          arrLevelHierarshi(i).lev15 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev15 then 
                          arrLevelHierarshi(i).lev14 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev14 then 
                          arrLevelHierarshi(i).lev13 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev13 then 
                          arrLevelHierarshi(i).lev12 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev12 then 
                          arrLevelHierarshi(i).lev11 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev11 then 
                          arrLevelHierarshi(i).lev10 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev10 then 
                          arrLevelHierarshi(i).lev09 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev09 then 
                          arrLevelHierarshi(i).lev08 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev08 then 
                          arrLevelHierarshi(i).lev07 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev07 then 
                          arrLevelHierarshi(i).lev06 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev06 then 
                          arrLevelHierarshi(i).lev05 := arrDimension(j).parent_name;
                       end if;                       
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev05 then 
                          arrLevelHierarshi(i).lev04 := arrDimension(j).parent_name;
                       end if;                       
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev04 then 
                          arrLevelHierarshi(i).lev03 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev03 then 
                          arrLevelHierarshi(i).lev02 := arrDimension(j).parent_name;
                       end if;
                          if arrDimension(j).member_name like arrLevelHierarshi(i).lev02 then 
                          arrLevelHierarshi(i).lev01 := arrDimension(j).parent_name;
                       end if;                       
                     
                    end loop;
             end if;
          end loop;
   end if;
  end loop;
   for i in 1..vI loop
    arrLevelHierarshi(i).lev01 :=vHierashiName;
    pipe row (arrLevelHierarshi(i));  
 end loop;
   EXCEPTION 
   WHEN NO_DATA_FOUND THEN     
        return;
   WHEN  NO_DATA_NEEDED THEN 
        return;
   WHEN  OTHERS THEN   
            XMLA_UTIL_PKG.srvWriteError  ('Error Detail' , DBMS_UTILITY.format_error_backtrace) ;
            XMLA_UTIL_PKG.srvWriteError  ('vTextBuffer' , vTextBuffer) ;
            XMLA_UTIL_PKG.srvWriteError  ('vApsConnect' ,  vApsConnect) ; 
          RAISE; 
   end ;
 
END xmla_get_data_PKG;
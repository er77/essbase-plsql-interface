﻿create or replace
PACKAGE XMLA.xmla_job_manager_pkg AS

 
 
procedure runJob( vMdxQuery   VARCHAR2    ,vApsConnect VARCHAR2,vEsbConnect VARCHAR2, vJobIDIN number  )   ;
 
FUNCTION getDataFromJobSeq   ( vMdxQuery   VARCHAR2, vFindString VARCHAR2   ,vReplaceStringArray VARCHAR2 ,vTypeOfStrings VARCHAR2 DEFAULT 'list' ) RETURN XMLA_UTIL_PKG.essbaseCrossJoin_T  
parallel_enable  PIPELINED;
  
/*

--exec sys.dbms_shared_pool.KEEP (  'XMLA.XX_XMLA_CACHE' ,'Q');

select * from ( table( XMLA_JOB_MANAGER_PKG.getDataFromJobSeq(
                             '
                             SELECT NON EMPTY {( [Actual])} ON COLUMNS,
                            NON EMPTY
                            CrossJoin (CrossJoin ([Product].children, [#Market#].children),
                            CrossJoin([Year].Children, [Measures].children))
                            ON ROWS
                            FROM Sample.Basic',
                            '#Market#',
                            'South,Central,West,East,')
                        )  
                  )
                  
                 
                  
                   select * from ( table( XMLA_JOB_MANAGER_PKG.getDataFromJobSeq(
                             'SELECT NON EMPTY  {( [y992011])} ON COLUMNS, 
   NON EMPTY  CrossJoin (CrossJoin ([#TNVED#].children, [Direction].children),CrossJoin
	 (CrossJoin([Strana].children,[PrStat].children),
	 [Measures].children))
   ON ROWS
    FROM T2.T2 ',
                            '#TNVED#',
                            'tG01-24,tG25-27,tG28-40,tG41-43,tG44-49,tG50-67,')
                        )  
                  )
                  
                  
        */     
END xmla_job_manager_pkg;
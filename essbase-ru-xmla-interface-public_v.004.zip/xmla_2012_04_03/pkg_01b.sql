﻿create or replace
PACKAGE BODY XMLA.XMLA_UTIL_pkg AS


  
  
  function getHash (vString Varchar2 ) return number as
   PRAGMA AUTONOMOUS_TRANSACTION;  
   vRetVal NUMBER;
   begin 
    SELECT ORA_HASH(vString) INTO vRetVal FROM DUAL;
       RETURN vRetVal;
     EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('getHash  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE;  
   end;
 
  
  procedure  sendAlertSignal  (vJob number,vJobResult number)  as 
 --PRAGMA AUTONOMOUS_TRANSACTION;  
begin
  update XMLA.XX_XMLA_JOB_POOL set jobresult=vJobResult where JOB= vJob ;  
commit;
     EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('sendAlertSignal  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
end ;

procedure  registerAlert (vSeq number,vJob number) as
 PRAGMA AUTONOMOUS_TRANSACTION;  
begin
   INSERT INTO XMLA.XX_XMLA_JOB_POOL (SEQ, JOB,jobresult) VALUES
  ( vSeq, vJob,0); 
commit;
     EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('registerAlert  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
end ;

procedure  removeAlert (vSeq number,vJob number)  as
 PRAGMA AUTONOMOUS_TRANSACTION; 
  begin
    delete from XMLA.XX_XMLA_JOB_POOL where (SEQ=vSeq and  jobresult = vJob ) ;
  commit; 
        EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('removeAlert  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
  end; 

  procedure  waitanyAlert (vSeq number,    vJobResult out number ) as
 --  PRAGMA AUTONOMOUS_TRANSACTION; 
  begin  
  vJobResult :=null;
   for cr in ( select   jobresult  from  XMLA.XX_XMLA_JOB_POOL  where seq=vSeq and  NVL(jobresult,0) not in ( 0,1) -- for update nowait 
   ) loop
        vJobResult := cr.jobresult; 
   end loop;
    if vJobResult is null then 
      dbmsSleep (0.1);
    end if ;
        EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('waitanyAlert  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
  end ;
  
 

 function getJobNumber return number as 
 PRAGMA AUTONOMOUS_TRANSACTION;  
 vJobNumber number;
  begin
 vJobNumber :=-111; 
  SELECT (to_number(to_char(SYSDATE, 'YYYYMMDDHH24MISS') || seqJobId.nextval )) jobid INTO vJobNumber FROM dual;
 return vJobNumber; 
       EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('getJobNumber  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
 end ;

  procedure srvWriteError (vERRCode VARCHAR2, vERRMessages VARCHAR2) AS
  vErrNumber number ;
PRAGMA AUTONOMOUS_TRANSACTION;  
   begin 
   select SEQerrID.nextval into vErrNumber from dual;
   
         INSERT
    INTO XX_XMLA_ORA_ERROR   (  ERR_CODE,  ERR_MESSAGE )
      VALUES  (substr( vErrNumber||' '|| vERRCode,1,3200), vERRMessages );
    commit;
    dbms_output.put_line (vERRCode);  
    dbms_output.put_line (vERRMessages);  
  END srvWriteError;
  
  procedure dbmsSleep ( vTime number )
as PRAGMA AUTONOMOUS_TRANSACTION;  
 begin 
  sys.dbms_lock.sleep(vTime);
end ;  

   procedure dbmsCreateJob ( vJobName varchar2,   vJobAction varchar2 ) as 
      PRAGMA AUTONOMOUS_TRANSACTION;  
   begin
     DBMS_SCHEDULER.CREATE_JOB
                      ( job_name   => vJobName
                      , job_type   => 'PLSQL_BLOCK'
                      , job_action => 'begin '||vJobAction||'; end; '
                      , enabled   => TRUE
                      , auto_drop => TRUE
     );
      EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('dbmsCreateJob  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE;               
   end;
   

 
   
  procedure runDeleteCacheForJob( vjobID  number) as 
     PRAGMA AUTONOMOUS_TRANSACTION;  
  begin
      dbmsCreateJob ( 'DJ'||vjobID, 'XMLA_UTIL_PKG.srvDeleteCacheForJob('||vjobID||')' )  ; 
       
    /*     delete from XX_XMLA_JOB_MONITOR where job_id =  vjobID;
       commit; 
        delete from XX_XMLA_CACHE where job_id =  vjobID; 
       commit; 
      */ 
          EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('runDeleteCacheForJob  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
  end;

  procedure srvDeleteCacheForJob( vjobID  number) as 
     PRAGMA AUTONOMOUS_TRANSACTION;  
  begin
        
        delete from XX_XMLA_JOB_MONITOR where job_id =  vjobID;
       commit; 
        delete from XX_XMLA_CACHE where job_id =  vjobID; 
       commit; 
 
        EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('srvDeleteCacheForJob  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
  end;

  procedure runDeleteOldJobs as
        PRAGMA AUTONOMOUS_TRANSACTION;  
   begin
       dbmsCreateJob ( 'srvDeleteOldJobs', 'XMLA_UTIL_PKG.srvDeleteOldJobs()' )  ; 
     EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('runDeleteOldJobs  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE;     
   end ;
   
   
    procedure srvDeleteOldJobs as 
     PRAGMA AUTONOMOUS_TRANSACTION;  
   begin
    
        update   XX_XMLA_JOB_MONITOR set iserror=-2 where ( TIME_CREATION < (sysdate - vTimeToLeaveCahce ) and iserror=0 );
        
        commit;
    
        delete from xx_xmla_cache where  
                job_id in ( select job_id from  XX_XMLA_JOB_MONITOR where iserror <> 0 );
                 
       commit;  
      
        delete from XX_XMLA_JOB_MONITOR  where  iserror <> 0 ; -- delete olds jobs 
                 
       commit;            
       
       EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('srvDeleteOldJobs  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE;                
   end ;  
 
   procedure setUnlockEssbaseConect ( vEsbServer varchar2 ) as 
     PRAGMA AUTONOMOUS_TRANSACTION; 
   begin 
       update   xx_xmla_conection_pool set isRunning=0 where esb_server = vEsbServer ;
     commit;
     EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('setUnlockEssbaseConect  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE;  
   end;
 
  procedure waitFreeEssbaseConnect ( vEsbServer varchar2 ) as 
     PRAGMA AUTONOMOUS_TRANSACTION; 
    vIsEssbaseRunning number;
  begin 
    vIsEssbaseRunning :=0; 
  select isRunning into vIsEssbaseRunning from xx_xmla_conection_pool where esb_server = vEsbServer ;
  while 0 <  vIsEssbaseRunning loop 
    XMLA_UTIL_PKG.dbmsSleep (  0.1 ) ;
    select isRunning into vIsEssbaseRunning from xx_xmla_conection_pool where esb_server = vEsbServer ;
  end loop;
  
  update   xx_xmla_conection_pool set isRunning=1 where esb_server = vEsbServer ;
  commit;
  EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('waitFreeEssbaseConnect  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE;  
  end;
  
  procedure createViewForDatabase (vApsConnect varchar2,vEsbServer varchar2,vAppName varchar2,vDataBase varchar2) as 
     PRAGMA AUTONOMOUS_TRANSACTION; 
  
  vCurrTableName Varchar2(30);
  vSqlCommnad varchar2(32000) ;
 begin 
        for cr3 in (select Catalog_Name AppName, Cube_name CubeName, Dimension_Name DimensionName from ( table ( xmla_get_data_PKG.getDimensionList(vApsConnect, vEsbServer,vAppName , vDataBase   ) )) ) loop
          -- dbms_output.put_line          
          vCurrTableName:=' DIM_'|| substr(cr3.CubeName,1,6)||'_'||substr(replace(cr3.DimensionName,' '),1,11)||'_PCH_v';
          vSqlCommnad := 'create or replace view  '||vCurrTableName||'  as  select CUBE_NAME, MEMBER_NAME, PARENT_NAME  
            from ( table (
            xmla_get_data_PKG.getHierarshyMembersList(''http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA'' , ''127.0.0.1'' ,'''||cr3.AppName||''','''||cr3.CubeName|| ''','''||cr3.DimensionName|| ''' ) ))  ';   
           --  dbms_output.put_line (vSqlCommnad );
           
               EXECUTE IMMEDIATE  vSqlCommnad ;
               
          vCurrTableName:=' DIM_'|| substr(cr3.CubeName,1,6)||'_'||substr(replace(cr3.DimensionName,' '),1,11)||'_LEV_v';
          vSqlCommnad := 'create or replace view  '||vCurrTableName||'  as  select *   
            from ( table (
            xmla_get_data_PKG.getHierarshyByLevel(''http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA'' , ''127.0.0.1'' ,'''||cr3.AppName||''','''||cr3.CubeName|| ''','''||cr3.DimensionName|| ''' ) ))  ';    
           
           EXECUTE IMMEDIATE  vSqlCommnad ;
               
              commit; 
        end loop;
 
 
  EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('createViewForDatabase  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
end ;


  procedure createViewForServer (vApsConnect varchar2,vEsbServer varchar2) as 
     PRAGMA AUTONOMOUS_TRANSACTION; 
 begin  
   for cr1 in ( select AppName from ( table ( xmla_get_data_PKG.getApplications(vApsConnect, vEsbServer   ) )) ) loop
     for cr2 in (select AppName,CubeName  from ( table ( xmla_get_data_PKG.getDataBase(vApsConnect, vEsbServer  ,cr1.AppName ) )) ) loop     
        createViewForDatabase (vApsConnect ,vEsbServer ,cr2.AppName ,cr2.AppName );        
     end loop;
   end loop;
 
  EXCEPTION  
    when others then -- set Label for display error 
       XMLA_UTIL_PKG.srvWriteError ('createViewForServer  '||SQLCODE, SQLERRM) ;  
       XMLA_UTIL_PKG.srvWriteError ('Error Detail',DBMS_UTILITY.format_error_backtrace) ;
    RAISE; 
end ;
    

END XMLA_UTIL_pkg;
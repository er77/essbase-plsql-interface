﻿ set serveroutput on ;
 declare 
  vCurrTableName Varchar2(30);
  vSqlCommnad varchar2(32000) ;
 begin
  
   for cr1 in ( select AppName from ( table ( xmla_get_data_PKG.getApplications('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1'   ) )) ) loop
     for cr2 in (select AppName,CubeName  from ( table ( xmla_get_data_PKG.getDataBase('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,cr1.AppName ) )) ) loop
        for cr3 in (select Catalog_Name AppName, Cube_name CubeName, Dimension_Name DimensionName from ( table ( xmla_get_data_PKG.getDimensionList('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,cr2.AppName , cr2.CubeName   ) )) ) loop
          -- dbms_output.put_line 
         
          vCurrTableName:=' DIM_'|| substr(cr3.CubeName,1,6)||'_'||substr(replace(cr3.DimensionName,' '),1,11)||'_PCH_v';
          vSqlCommnad := 'create or replace view  '||vCurrTableName||'  as  select CUBE_NAME, MEMBER_NAME, PARENT_NAME  
            from ( table (
            xmla_get_data_PKG.getHierarshyMembersList(''http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA'' , ''127.0.0.1'' ,'''||cr3.AppName||''','''||cr3.CubeName|| ''','''||cr3.DimensionName|| ''' ) ))  ';   
           --  dbms_output.put_line (vSqlCommnad );
               EXECUTE IMMEDIATE  vSqlCommnad ;
               
          vCurrTableName:=' DIM_'|| substr(cr3.CubeName,1,6)||'_'||substr(replace(cr3.DimensionName,' '),1,11)||'_LEV_v';
          vSqlCommnad := 'create or replace view  '||vCurrTableName||'  as  select *   
            from ( table (
            xmla_get_data_PKG.getHierarshyByLevel(''http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA'' , ''127.0.0.1'' ,'''||cr3.AppName||''','''||cr3.CubeName|| ''','''||cr3.DimensionName|| ''' ) ))  ';    
           
           EXECUTE IMMEDIATE  vSqlCommnad ;
               
              commit; 
        end loop;
     end loop;
   end loop;
 end;
﻿create or replace
package XMLA.xmla_get_data_PKG is
 /* alter session set PLSQL_CODE_TYPE=NATIVE; */
   FUNCTION getXmlaData  ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2  ) RETURN  XMLA_UTIL_PKG.varchar2_table   parallel_enable  PIPELINED ;
    
    
  FUNCTION getMdxValue (vMdxQuery VARCHAR2,vApsConnect VARCHAR2,vEsbConnect VARCHAR2 )   RETURN XMLA_UTIL_PKG.essbaseCrossJoin_t  
        parallel_enable PIPELINED ; 
         
  FUNCTION getDimensionList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2 )        RETURN XMLA_UTIL_PKG.DimensionList_T 
         parallel_enable PIPELINED ;
         
   FUNCTION getApplications (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2  ) RETURN XMLA_UTIL_PKG.AppName_T   parallel_enable  PIPELINED ;       
  
  FUNCTION getDataBase (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2, vApplicationName VARCHAR2  ) RETURN XMLA_UTIL_PKG.cubeName_T   parallel_enable  PIPELINED ;
  
   FUNCTION getHierarshyList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN XMLA_UTIL_PKG.varchar2_table
  parallel_enable  PIPELINED ;
  
  
   FUNCTION getHierarshyMembersList (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN XMLA_UTIL_PKG.essbaseHierarshi_T
  parallel_enable  PIPELINED ;
  
    FUNCTION getHierarshyByLevel  (  vApsConnect VARCHAR2,vEsbConnect VARCHAR2 , vApplicationName VARCHAR2, vDatabaseName VARCHAR2, vHierashiName VARCHAR2 ) RETURN XMLA_UTIL_PKG.levelHierarshi_T
  parallel_enable  PIPELINED ; 
  
  function createCache  ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2, vJobIdIn number  ) return number;
  procedure runCreateCache ( vXmlaBody VARCHAR2,  vApsConnect VARCHAR2, vJobIdIN number  ) ;

/*
  select * from ( table ( xmla_get_data_PKG.getDimensionList('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'sample' ,  'basic' ) )) ; 
  
  select * from ( table ( xmla_get_data_PKG.getApplications('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1'   ) )) ; 
 
  select * from ( table ( xmla_get_data_PKG.getDataBase('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'Sample'  ) )) ; 
  
  select * from ( table ( xmla_get_data_PKG.getHierarshyMembersList('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'sample' ,  'basic','year' ) )) ;  
  
   select * from ( table ( xmla_get_data_PKG.getHierarshyByLevel('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'sample' ,  'basic','year' ) )) ;  
   
     
   select * from ( table ( xmla_get_data_PKG.getHierarshyList('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1' ,'sample' ,  'basic','year' ) )) ; 
 
 select * from table (xmla_get_data_PKG.getMdxValue(
'  
  SELECT NON EMPTY  {( [Actual])} ON COLUMNS, 
   NON EMPTY  CrossJoin (CrossJoin ([Measures].children, [Product].children),
 [Market].children
	 )
   ON ROWS
    FROM sample.basic
','http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' , '127.0.0.1'
)) 
*/

 
  
end xmla_get_data_PKG;
﻿create or replace
PACKAGE      xmla.XMLA_UTIL_pkg AS 


  vIsEssbaseCachable Number :=1;  
  vTimeToLeaveCahce Number :=1/24;   --1/24 one hour 
  vThreadCount Number :=3;  
  /* for avoiding network error please open all ports 
    like TcpTimedWaitDelay = 300
         MaxUserPort  65534*/
  vIsDebugSOA number :=0; --write in xx_xmla_error all http body
    
 Type varchar2_table Is Table Of clob; 
 
 
   TYPE essbaseCrossJoin_r IS RECORD
  ( dim01  VARCHAR2(80) ,
    dim02  VARCHAR2(80) ,
    dim03  VARCHAR2(80) ,
    dim04  VARCHAR2(80) ,
    dim05  VARCHAR2(80) ,
    dim06  VARCHAR2(80) ,
    dim07  VARCHAR2(80) ,
    dim08  VARCHAR2(80) ,
    dim09  VARCHAR2(80) ,
    dim10  VARCHAR2(80) ,
    dim11  VARCHAR2(80) ,
    dim12  VARCHAR2(80) ,
    dim13  VARCHAR2(80) ,
    dim14  VARCHAR2(80) ,
    dim15  VARCHAR2(80) ,
    dim16  VARCHAR2(80) ,
    dim17  VARCHAR2(80) ,
    dim18  VARCHAR2(80) ,
    dim19  VARCHAR2(80) ,
    dim20  VARCHAR2(80) ,
    dim21  VARCHAR2(80) ,
    DblValue number 
    );
  TYPE essbaseCrossJoin_T IS TABLE OF essbaseCrossJoin_r; 
  
  
   
   TYPE levelHierarshi_r IS RECORD
  ( lev01  VARCHAR2(80) ,
    lev02  VARCHAR2(80) ,
    lev03  VARCHAR2(80) ,
    lev04  VARCHAR2(80) ,
    lev05  VARCHAR2(80) ,
    lev06  VARCHAR2(80) ,
    lev07  VARCHAR2(80) ,
    lev08  VARCHAR2(80) ,
    lev09  VARCHAR2(80) ,
    lev10  VARCHAR2(80) ,
    lev11  VARCHAR2(80) ,
    lev12  VARCHAR2(80) ,
    lev13  VARCHAR2(80) ,
    lev14  VARCHAR2(80) ,
    lev15  VARCHAR2(80) ,
    lev16  VARCHAR2(80) ,
    lev17  VARCHAR2(80) ,
    lev18  VARCHAR2(80) ,
    lev19  VARCHAR2(80) ,
    lev20  VARCHAR2(80) ,
    lev21  VARCHAR2(80) 
    );
  TYPE levelHierarshi_T IS TABLE OF levelHierarshi_r; 
   
     TYPE cubeName_r IS RECORD
  ( AppName  VARCHAR2(80),
    CubeName  VARCHAR2(80)   
    );
  TYPE cubeName_T IS TABLE OF cubeName_r; 

   TYPE AppName_r IS RECORD
  ( AppName  VARCHAR2(80)  
    );
  TYPE AppName_T IS TABLE OF AppName_r; 
 
 TYPE DimensionList_r IS RECORD
( 
  CATALOG_NAME  VARCHAR2(20) ,
  CUBE_NAME  VARCHAR2(20) ,
  DIMENSION_NAME  VARCHAR2(20) ,
  DIMENSION_UNIQUE_NAME  VARCHAR2(20) ,
  DIMENSION_CAPTION  VARCHAR2(20) ,
  DIMENSION_ORDINAL number ,
  DIMENSION_TYPE   number ,
  DIMENSION_CARDINALITY number ,
  DEFAULT_HIERARCHY  VARCHAR2(20) ,
  DESCRIPTION  VARCHAR2(20) ,
  DIMENSION_UNIQUE_SETTINGS  number ,
  DIMENSION_IS_VISIBLE  VARCHAR2(20) 
 );
 
 TYPE DimensionList_T IS TABLE OF DimensionList_r; 
   
   
    TYPE essbaseMember_r IS RECORD
  (   CATALOG_NAME varchar2(80) ,
      CUBE_NAME varchar2(80) ,
      DIMENSION_UNIQUE_NAME varchar2(80) ,
      HIERARCHY_UNIQUE_NAME varchar2(80) ,
      LEVEL_UNIQUE_NAME varchar2(80) ,
      LEVEL_NUMBER number ,
      GENERATION_NUMBER number ,
      MEMBER_ORDINAL varchar2(80)  ,
      MEMBER_NAME varchar2(80) ,
      MEMBER_UNIQUE_NAME varchar2(80) ,
      MEMBER_TYPE varchar2(80) ,
      MEMBER_CAPTION varchar2(80) ,
      CHILDREN_CARDINALITY number ,
      PARENT_LEVEL number ,
      PARENT_UNIQUE_NAME varchar2(80) ,
      PARENT_NAME varchar2(80) ,
      PARENT_COUNT number ,
      somes varchar2(80)   
  );
  
   TYPE essbaseHierarshi_T IS TABLE OF essbaseMember_r; 
   
  procedure createViewForServer (vApsConnect varchar2,vEsbServer varchar2) ;
   -- create view exec XMLA_UTIL_pkg.createViewForServer ('http://hypadmin:hyperion@127.0.0.1:13080/aps/XMLA' ,'127.0.0.1') ;
  procedure createViewForDatabase (vApsConnect varchar2,vEsbServer varchar2,vAppName varchar2,vDataBase varchar2) ;
  
  procedure srvWriteError (vERRCode VARCHAR2, vERRMessages VARCHAR2);
  
  procedure runDeleteOldJobs ;
  procedure srvDeleteOldJobs ;
   
  procedure srvDeleteCacheForJob( vjobID  number) ;
  procedure runDeleteCacheForJob( vjobID  number) ;
  
  function getJobNumber return number ;
  
  function getHash (vString Varchar2 ) return number;
  
  procedure dbmsSleep ( vTime number );
  
  procedure waitFreeEssbaseConnect ( vEsbServer varchar2 );
  procedure setUnlockEssbaseConect ( vEsbServer varchar2 );
 
  procedure dbmsCreateJob ( vJobName varchar2,   vJobAction varchar2 ) ;
   
  --http://www.plsql.msk.ru/paketi_dlya_vzaimodeystviya_mezhdu_sessiyami/paket_dbms_alert
  procedure  sendAlertSignal  (vJob number,vJobResult number) ;
  procedure  registerAlert (vSeq number,vJob number) ;
  procedure  removeAlert (vSeq number,vJob number) ;
  procedure  waitanyAlert (vSeq number,    vJobResult out number );
 

END XMLA_UTIL_pkg;